<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Marketing Marterial</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>

<body>
    <section class="mainsec">
        <section class="marketing">
            <img src="img/maicon.png" alt="icon" id="maicon">
            <p id="mm">Marketing Marterial</p>
            <input type="text" name="Search" placeholder="Search">
        </section>
        <section class="submarketing">
            <button onclick="fav()" id="fav"><img src="img/star.png" alt="star icon" id="staricon"></button>
            <button onclick="selectall()" id="selectall">Select All</button>
            <section class="popup" onclick="myFunction()" id="unselectall">Unselect All
                <span class="popuptext" id="myPopup">Are you sure you want to unselect all?
                            <button><i class="material-icons">clear</i></button>
            <br>
            <button id="yes" onclick="">Yes</button>
            <button id="no" onclick="">No</button>
            </span>
            </section>
            <section class="popupdown" onclick="myFunctiondown()" id="download">Download
                <span class="popuptextdown" id="myPopupdown">Do you want to download all files?
                            <button><i class="material-icons">clear</i></button>
            <br>
            <button id="yes" onclick="">Yes</button>
            <button id="no" onclick="">No</button>
            </span>
            </section>
        </section>
    </section>

    <script>
        // When the user clicks on a button, the popup opens
        function myFunction() {
            var popup = document.getElementById("myPopup");
            popup.classList.toggle("show");
        }

        function myFunctiondown() {
            var popupdown = document.getElementById("myPopupdown");
            popupdown.classList.toggle("show");
        }
    </script>
</body>

</html>