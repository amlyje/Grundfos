<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Front page/Tabs</title>
<!--W3 framework, Icons, stylesheet, JS-->
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">

</head>


<body>
<main class="w3-cell-row w3-container w3-center">
<div class="w3-cell">
<header>
<h4 class="header-color">
<i class="fa fa-star fa-3x star"></i>
Favourites</h4>	
</header>

<section class="w3-cell-row w3-border content">
<div class="w3-cell">
<ol>
<li>test</li>	
<li>test</li>
<li>test</li>
<li>test</li>
<li>test</li>
<li>test</li>
</ol>	
</div>
</section>
<!--Button-->
<div class="tab">
<button class="tablinks" onclick="openTab(event, 'Fav')">Show more!</button>
</div>
</div>

<div class="w3-cell">
<header>
<h4 class="header-color">
<i class="fa fa-eye fa-3x eye"></i>
Last Viewed</h4>	
</header>
<section class="w3-cell-row w3-border content">
<div class="w3-cell">
<ol>
<li>test</li>	
<li>test</li>
<li>test</li>
<li>test</li>
<li>test</li>
<li>test</li>
</ol>		
</div>
</section>
<!--Button-->
<div class="tab">
<button class="tablinks" onclick="openTab(event, 'LastV')">Show more!</button>
</div>
</div>
</main>
<!--Tabs-->
<!--Favourte tab-->
<div id="Fav" class="tabcontent">
<div class="w3-container">
<div class="w3-grey w3-center w3-text-blue w3-top-middle">
<h2>My Favourites</h2>
</div>
<!--List of items-->
<section class="w3-left-align w3-xxlarge">
<li class="w3-display-container">Product1 IMG 
  <span onclick="this.parentElement.style.display='none'" 
  class="w3-button w3-display-right">&times;</span>
</li>
<li class="w3-display-container">Product2 VID
  <span onclick="this.parentElement.style.display='none'" 
  class="w3-button w3-display-right">&times;</span>
</li>
<li class="w3-display-container">Product3 Brochure 
  <span onclick="this.parentElement.style.display='none'" 
  class="w3-button w3-display-right">&times;</span>
</li>
</section>
</div>
</div>
<!--Last Vieved tab-->
<div id="LastV" class="tabcontent">
<div class="w3-container">
<div class="w3-grey w3-center w3-text-blue w3-top-middle">
<h2>Last Viewed</h2>
</div>
</div>
</div>
<?php
include 'folders.php'
?>
<script src="http://code.jquery.com/jquery-1.7.1.js"></script>
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="js/js.js"></script>
</body>
</html>